package org.test.glue.definition;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v123.audits.model.FederatedAuthRequestIssueDetails;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.page.factory.PnrGenerationFactory;
import org.test.util.DateUtil;
import org.test.util.GenericConstants;
import org.test.util.Utility;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PnrGenerationDefinition {

	WebDriver driver = null;
	JavascriptExecutor js = null;
	WebDriverWait wait = null;
	PnrGenerationFactory element = null;
	Calendar cal = Calendar.getInstance();
	Map<String, String> dataMap = new HashMap<String, String>();

	@Before
	public void init() {
		driver = Utility.launchDriver("chrome");
		wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		js = (JavascriptExecutor) driver;
	}

	@Given("Home page of fly dubai Book flight and route information to search route")
	public void home_page_of_fly_dubai_book_flight_and_route_information_to_search_route() {
		try {
			driver.navigate().to(GenericConstants.HOME_URL);
			element = new PnrGenerationFactory(driver);
			wait.until(ExpectedConditions.elementToBeClickable(element.getCookies()));
			element.getCookies().click();

			wait.until(ExpectedConditions.elementToBeClickable(element.getOrigin()));

			element.enterOrigin(GenericConstants.ORIGIN);
			element.getOrigin().sendKeys(Keys.TAB);

			element.enterDestination(GenericConstants.DESTINATION);
			element.getDestination().sendKeys(Keys.TAB);

			wait.until(ExpectedConditions.elementToBeClickable(element.getCalendarWidget()));

			Utility.selectdate(driver, Utility.getCurrentDayPlus(1), element.getCalendarDays());

			Utility.selectdate(driver, Utility.getCurrentDayPlus(2), element.getCalendarDays());

			element.getSearchElement().click();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Given("select departure flight tab and chose fare band")
	public void select_departure_flight_tab_and_chose_fare_band() {
		try {
			if (element.getCookies().isDisplayed()) {
				element.getCookies().click();
			}
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("flight-list-item-container")));
			js.executeScript("arguments[0].scrollIntoView();", element.getFlightListContainer().get(0));
			Thread.sleep(4000);
			element.getFlightListContainer().get(0).click();

			// Filling input parameters for future validation
			WebElement departureFlightElement = element.getFlightListContainer().get(0);

			List<WebElement> flightData = departureFlightElement.findElements(By.className("stationCodeAndTime"));
			for (int i = 0; i < flightData.size(); i++) {
				WebElement fData = flightData.get(i);
				if (i == 0) {
					dataMap.put("dep_departureTime", fData.findElement(By.id("divDate")).getText());
					dataMap.put("dep_departureLocation", fData.findElement(By.id("lblStationCode")).getText());
				} else if (i == 1) {
					dataMap.put("dep_arrivalTime", fData.findElement(By.id("divDate")).getText());
					dataMap.put("dep_arrivalLocation", fData.findElement(By.id("lblStationCode")).getText());
				}
			}

			dataMap.put("departureDate",
					driver.findElements(By.className("tripHeaderDate")).get(0).findElement(By.id("divDate")).getText());
			
			dataMap.put("dep_aircraft_Name", departureFlightElement.findElement(By.className("aircraft-title"))
					.findElement(By.className("flight-aircraft-type")).getText());

			wait.until(ExpectedConditions.elementToBeClickable(By.className("fare-brand-btn")));
			List<WebElement> fareOptions = driver.findElements(By.className("fare-brand-btn"));

			for (int i = 1; i < fareOptions.size(); i++) {
				WebElement webElement = fareOptions.get(i);
				wait.until(ExpectedConditions.elementToBeClickable(webElement));
				System.out.println(webElement.getAttribute("class"));
				Thread.sleep(4000);
				js.executeScript("arguments[0].scrollIntoView();", webElement);
				webElement.click();
				break;
			}

		} catch (StaleElementReferenceException stale) {
			stale.printStackTrace();
			wait.until(ExpectedConditions.elementToBeClickable(element.getCookies()));
			element.getCookies().click();
			select_departure_flight_tab_and_chose_fare_band();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Given("select return flight and chose fare band")
	public void select_return_flight_and_chose_fare_band() {
		try {
			Thread.sleep(4000);
			WebElement availableDepartureFlight = driver.findElement(By.cssSelector(
					"#desktopHeader > div.flex-basis-css.return-journey-page > div > div.returnOverlayBckgrnd.returnOverlayBckgrndAftrClick > fz-desktop-availability-list > div.avail-list-desk > div > div > div:nth-child(1) > fz-desktop-flight-availability-list-item > div > div"));
			wait.until(ExpectedConditions.visibilityOf(availableDepartureFlight));
			js.executeScript("arguments[0].scrollIntoView();", availableDepartureFlight);
			availableDepartureFlight.click();

			List<WebElement> flightData = availableDepartureFlight.findElements(By.className("stationCodeAndTime"));
			for (int i = 0; i < flightData.size(); i++) {
				WebElement fData = flightData.get(i);
				if (i == 0) {
					dataMap.put("return_departureTime", fData.findElement(By.id("divDate")).getText());
					dataMap.put("return_departureLocation", fData.findElement(By.id("lblStationCode")).getText());
				} else if (i == 1) {
					dataMap.put("return_arrivalTime", fData.findElement(By.id("divDate")).getText());
					dataMap.put("return_arrivalLocation", fData.findElement(By.id("lblStationCode")).getText());
				}
			}
			dataMap.put("returnDate",
					driver.findElements(By.className("tripHeaderDate")).get(1).findElement(By.id("divDate")).getText());

			dataMap.put("return_aircraft_Name", availableDepartureFlight.findElement(By.className("aircraft-title"))
					.findElement(By.className("flight-aircraft-type")).getText());

			Thread.sleep(4000);
			WebElement fareBand = driver.findElement(By.cssSelector(
					"#desktopHeader > div.flex-basis-css.return-journey-page > div > div.returnOverlayBckgrnd.returnOverlayBckgrndAftrClick > fz-desktop-availability-list > div.avail-list-desk > div > div > div:nth-child(1) > div.expandedModel.ng-star-inserted > div > div > div > div.fareBrandBox > div:nth-child(3) > div > fz-fare-brand-column > div > div.Value.fare-faretype > div.fare-brand-btn > fz-button"));
			wait.until(ExpectedConditions.visibilityOf(fareBand));
			js.executeScript("arguments[0].scrollIntoView();", fareBand);
			fareBand.click();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@When("baggae information displayed select Extra baggage")
	public void baggae_information_displayed_select_extra_baggage() {
		try {
			System.out.println("4");
			Thread.sleep(10000);

			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text() = \"+10 KG\"]")));
			WebElement extrabaggage = driver.findElement(By.xpath("//label[text() = \"+10 KG\"]"));
			js.executeScript("arguments[0].scrollIntoView();", extrabaggage);
			extrabaggage.click();

			Thread.sleep(4000);

			WebElement extrabaggage1 = driver.findElement(By.xpath("//label[text() = \"+10 KG\"]"));
			wait.until(ExpectedConditions.visibilityOf(extrabaggage1));
			js.executeScript("arguments[0].scrollIntoView();", extrabaggage1);
			extrabaggage1.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@When("click continue to passenger details")
	public void click_continue_to_passenger_details() {
		// Write code here that turns the phrase above into concrete actions
		try {
			Thread.sleep(3000);
			WebElement passengerDetails = driver.findElement(By.className("navigateToPassengerDetails"));
			wait.until(ExpectedConditions.elementToBeClickable(passengerDetails));
			js.executeScript("arguments[0].scrollIntoView();", passengerDetails);
			passengerDetails.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@When("passenger details page display fill passgenger details")
	public void passenger_details_page_display_fill_passgenger_details() {
		System.out.println("1");
		try {
			Thread.sleep(3000);
			element.getFirstName().sendKeys("Satvir");
			element.getLastName().sendKeys("Singh");
			element.getEmailAddress().sendKeys("me.satvirsingh@gmail.com");
			element.getGenderMale().click();
			element.getCountryCodeDropdown().click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"countryValueCode\"]")));
			List<WebElement> countryCodeList = driver.findElements(By.xpath("//*[@id=\"countryValueCode\"]"));
			for (WebElement countryElement : countryCodeList) {
				if (countryElement.getText().equalsIgnoreCase("India")) {
					countryElement.click();
					break;
				}
			}

			dataMap.put("passenger_count", driver.findElement(By.className("passenger_count")).getText());
			element.getmobileNumber().sendKeys("9540238887");

			driver.findElement(By.id("flightDetailsAccordion")).click();
			int count = 0;
			for (WebElement fareDetails : driver.findElement(By.className("desktop-trip-summary-cart"))
					.findElements(By.className("depart-journey"))) {
				for (int amountIndex = 0; amountIndex < fareDetails.findElements(By.id("lblAmount"))
						.size(); amountIndex++) {
					WebElement fareAmount = fareDetails.findElements(By.id("lblAmount")).get(amountIndex);
					if (count == 0) {
						if (amountIndex == 0) {
							dataMap.put("departure_fare", fareAmount.getText());
						} else if (amountIndex == 1) {
							dataMap.put("departure_tax", fareAmount.getText());
						} else if (amountIndex == 2) {
							dataMap.put("departure_total", fareAmount.getText());
						}
					} else if (count == 1) {
						if (amountIndex == 0) {
							dataMap.put("return_fare", fareAmount.getText());
						} else if (amountIndex == 1) {
							dataMap.put("return_tax", fareAmount.getText());
						} else if (amountIndex == 2) {
							dataMap.put("return_total", fareAmount.getText());
						}
					}
				}
				count++;
			}

			dataMap.put("total_fare", driver.findElement(By.id("fareLbl")).findElement(By.id("lblAmount")).getText());

			element.getNextPassenger().click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("Reveiw booking")
	public void reveiw_booking() {
		
		try {

		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("flight-info")));
		for (int flightIndex = 0; flightIndex < driver.findElements(By.className("flight-info"))
				.size(); flightIndex++) {
			if(flightIndex == 0) {
				Assert.assertEquals(dataMap.get("dep_aircraft_Name"), driver.findElements(By.className("flight-info")).get(flightIndex).findElement(By.id("interLineMsg")).getText());
			}else if(flightIndex == 1) {
				Assert.assertEquals(dataMap.get("return_aircraft_Name"),  driver.findElements(By.className("flight-info")).get(flightIndex).findElement(By.id("interLineMsg")).getText());
			}

			for (int scheduleIndex = 0; scheduleIndex < driver.findElements(By.className("flight-info"))
					.get(flightIndex).findElements(By.className("stationCodeAndTime")).size(); scheduleIndex++) {
				WebElement fData = driver.findElements(By.className("flight-info")).get(flightIndex)
						.findElements(By.className("stationCodeAndTime")).get(scheduleIndex);
				if (flightIndex == 0) {
					if (scheduleIndex == 0) {
						Assert.assertEquals(dataMap.get("dep_departureTime"),
								fData.findElement(By.id("divDate")).getText());
						//Assert.assertEquals(dataMap.get("dep_departureLocation"),
								//fData.findElement(By.className("flightStationCode")).findElement(By.xpath("//*[@id=\"lblStationCode\"]")).getText());
					} else if (scheduleIndex == 1) {
						Assert.assertEquals(dataMap.get("dep_arrivalTime"),
								fData.findElement(By.id("divDate")).getText());
					//	Assert.assertEquals(dataMap.get("dep_arrivalLocation"),
							//	fData.findElement(By.id("lblStationCode")).getText());
					}
				} else if (flightIndex == 1) {
					if (scheduleIndex == 0) {
						Assert.assertEquals(dataMap.get("return_departureTime"),
								fData.findElement(By.id("divDate")).getText());
						//Assert.assertEquals(dataMap.get("return__departureLocation"),
							//	fData.findElement(By.id("lblStationCode")).getText());
					} else if (scheduleIndex == 1) {
						Assert.assertEquals(dataMap.get("return_arrivalTime"),
								fData.findElement(By.id("divDate")).getText());
					//	Assert.assertEquals(dataMap.get("return__arrivalLocation"),
							//	fData.findElement(By.id("lblStationCode")).getText());
					}
				}

			}
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("flightTypeLabel")));
		if (driver.findElement(By.className("flightTypeLabel")).getText().contains("Departing flight")) {
			driver.findElement(By.className("flightTypeLabel")).click();
		}

		for (int fareIndex = 1; fareIndex < driver.findElement(By.className("fareBreakdownSummary"))
				.findElements(By.className("faresInBreakdown")).size() - 1; fareIndex++) {
			WebElement webElement = driver.findElement(By.className("fareBreakdownSummary"))
			.findElements(By.className("faresInBreakdown")).get(fareIndex);
			if (fareIndex == 1) {
				Assert.assertEquals(dataMap.get("departure_fare"), webElement.findElement(By.id("lblAmount")).getText());
			} else if (fareIndex == 2) {
				Assert.assertEquals(dataMap.get("departure_tax"), webElement.findElement(By.id("lblAmount")).getText());
			}
		}
		
		if (driver.findElement(By.className("mat-tab-list")).findElements(By.className("mat-tab-label-content")).get(1).findElement(By.className("flightTypeLabel")).getText().contains("Returning flight")) {
			driver.findElement(By.className("mat-tab-list")).findElements(By.className("mat-tab-label-content")).get(1).findElement(By.className("flightTypeLabel")).click();
		}
		Thread.sleep(2000);
		
		for (int fareIndex = 1; fareIndex < driver.findElement(By.className("fareBreakdownSummary"))
				.findElements(By.className("faresInBreakdown")).size() - 1; fareIndex++) {
			WebElement webElement = driver.findElement(By.className("fareBreakdownSummary"))
					.findElements(By.className("faresInBreakdown")).get(fareIndex);
			if (fareIndex == 1) {
				Assert.assertEquals(dataMap.get("return_fare"), webElement.findElement(By.id("lblAmount")).getText());
			} else if (fareIndex == 2) {
				Assert.assertEquals(dataMap.get("return_tax"), webElement.findElement(By.id("lblAmount")).getText());
			}
		}
		
		driver.findElement(By.className("reviewPagebutton")).click();
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

	@After
	void close() {
		driver.quit();
		driver.close();
	}

}
