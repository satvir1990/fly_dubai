package org.page.factory;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PnrGenerationFactory {
	WebDriver driver = null;

	public PnrGenerationFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@value='Search']")
	WebElement search;

	@FindBy(className = "osano-cm-accept-all")
	WebElement cookies;

	@FindBy(className = "lightpick__inner")
	WebElement calendarWidget;

	@FindBy(className = "lightpick__day")
	List<WebElement> calendarDays;

	@FindBy(id = "airport-origin")
	WebElement origin;

	@FindBy(id = "airport-destination")
	WebElement destination;

	@FindBy(className = "flightlistItems")
	List<WebElement> flightListContainer;
	
	

	@FindBy(id = "First_Name")
	WebElement firstName;

	@FindBy(id = "Last_Name")
	WebElement lastName;

	@FindBy(id = "Email_Address")
	WebElement emailAddress;

	@FindBy(xpath = "//*[@id=\"Male.Text\"]/label")
	WebElement genderMale;

	@FindBy(className = "country-code-dropdown")
	WebElement countryCodeDropdown;

	@FindBy(id = "Mobile_Number")
	WebElement mobileNumber;

	@FindBy(className = "next-passenger")
	WebElement nextPassenger;

	@FindBy(className = "reviewPagebutton")
	WebElement reviewPagebutton;

	public WebElement getSearchElement() {
		return this.search;
	}

	public WebElement getCookies() {
		return this.cookies;
	}

	public WebElement getOrigin() {
		return this.origin;
	}

	public WebElement getDestination() {
		return this.destination;
	}

	public void enterOrigin(String origin) {
		this.origin.sendKeys(origin);
	}

	public void enterDestination(String destination) {
		this.destination.sendKeys(destination);
	}

	public WebElement getFirstName() {
		return this.firstName;
	}

	public WebElement getLastName() {
		return this.lastName;
	}

	public WebElement getEmailAddress() {
		return this.emailAddress;
	}

	public WebElement getGenderMale() {
		return this.genderMale;
	}

	public WebElement getCountryCodeDropdown() {
		return this.countryCodeDropdown;
	}

	public WebElement getmobileNumber() {
		return this.mobileNumber;
	}

	public WebElement getNextPassenger() {
		return this.nextPassenger;
	}

	public WebElement getReviewPagebutton() {
		return this.reviewPagebutton;
	}

	public WebElement getCalendarWidget() {
		return this.calendarWidget;
	}
	public List<WebElement> getFlightListContainer() {
		return this.flightListContainer;
	}

	public List<WebElement> getCalendarDays() {
		return this.calendarDays;
	}

}
